﻿using HokejovaLigaORM.Databaze;
using HokejovaLigaORM.Databaze.ORM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static HokejovaLigaORM.Databaze.ORM.TrestTable;
using static HokejovaLigaORM.Databaze.ORM.TymHracTable;

namespace HokejovaLigaORM
{
    class Program
    {
        static void Main(string[] args)
        {      
            // BodovaniTable
            Console.WriteLine(BodovaniTable.Update(9,1,17,"A"));
            Bodovani bod = new Bodovani();
            bod.idZapas = 2;
            bod.idHrac = 10;
            bod.typ = "G";
            Console.WriteLine(BodovaniTable.Insert(bod));
            
            //HracTable

            foreach (Hrac h in HracTable.Detail(1))
            {
                 Console.WriteLine(h.idHrac + " " + h.jmeno + " " + h.prijmeni + " " + h.post + " " + h.cislo);
            }
            foreach (Hrac h in HracTable.Seznam("6"))
            {
                Console.WriteLine(h.idHrac + " " + h.jmeno + " " + h.prijmeni + " " + h.post + " " + h.cislo);
            }
            Hrac h1 = new Hrac();
            h1.idHrac = 31;
            h1.jmeno = "Sponge Bob";
            h1.prijmeni = "Square Pants";
            h1.post = "B";
            h1.cislo = 1;
            Console.WriteLine(HracTable.Insert(h1));

            Hrac h2 = new Hrac();
            h2.idHrac = 31;
            h2.jmeno = "Sponge";
            h2.prijmeni = "Square";
            h2.post = "O";
            h2.cislo = 11;
            Console.WriteLine(HracTable.Update(h2));

            // LigaTable
            foreach (LigaTable.Tabulka tab in LigaTable.DetailLigy(1))
            {
                Console.WriteLine(tab.Tym + " " + tab.GV + " " + tab.GO + " " + tab.body);
            }
            foreach (LigaTable.LigTab tab1 in LigaTable.SeznamLig())
            {
                Console.WriteLine(tab1.idRocnik + " " + tab1.nameRocnik + " " + tab1.idLiga + " " + tab1.nameLiga);
            }
            Liga l = new Liga();
            l.idLiga = 3;
            l.nazev = "2. liga";
            Console.WriteLine(LigaTable.Insert(l));
            Liga l1 = new Liga();
            l1.idLiga = 3;
            l1.nazev = "Radegast liga ";
            Console.WriteLine(LigaTable.Update(l1));                        
            
            // RocnikTable
            DateTime zacatek = new DateTime(2016, 9, 1);
            DateTime konec = new DateTime(2017, 5, 31);
            Rocnik r = new Rocnik();
            r.idRocnik = 5;
            r.idLiga = 3;
            r.nazev = "2016/2017";
            r.zacatek = zacatek.Date;
            r.konec = konec.Date;
            r.pocetKol = 52;
            Console.WriteLine(RocnikTable.Insert(r));

            Rocnik r2 = new Rocnik();
            r2.idRocnik = 5;
            r2.idLiga = 3;
            r2.nazev = "2016/2017";
            r2.zacatek = zacatek.Date;
            r2.konec = konec.Date;
            r2.pocetKol = 32;
            Console.WriteLine(RocnikTable.Update(r2));

            // TrestTable
            Trest t = new Trest();
            t.idTrest = 2;
            t.idHrac = 3;
            t.zacatek = new DateTime(2017, 4, 27).Date;
            t.konec = new DateTime(2017, 5, 31).Date;
            Console.WriteLine(TrestTable.Insert(t));
            Trest t1 = new Trest();
            t1.idTrest = 2;
            t1.idHrac = 5;
            t1.zacatek = new DateTime(2017, 4, 27).Date;
            t1.konec = new DateTime(2017, 5, 31).Date;
            Console.WriteLine(TrestTable.Update(t1));
            foreach(SeznamTrestu t2 in TrestTable.Seznam())
            {
                Console.WriteLine(t2.idHrac + " " + t2.jmeno + " " + t2.prijmeni + " " + t2.body + " " + t2.post + " " + t2.cislo+ " " + t2.zacatek.Date + " " + t2.konec.Date);
            }
            foreach(SeznamTrestu t3 in TrestTable.Detail("Kovář"))
            {
                Console.WriteLine(t3.idHrac + " " + t3.jmeno + " " + t3.prijmeni + " " + t3.body + " " + t3.post + " " + t3.cislo + " " + t3.zacatek.Date + " " + t3.konec.Date);
            }

            // TymHracTable
            TymHrac th = new TymHrac();
            th.tym = "CZ01020300";
            th.idHrac = 31;
            th.zacatek = new DateTime(2017, 4, 27).Date;
            Console.WriteLine(TymHracTable.Insert(th));
            TymHrac th1 = new TymHrac();
            th1.tym = "CZ01020300";
            th1.idHrac = 31;
            th1.zacatek = new DateTime(2017, 4, 27).Date;
            th1.konec = new DateTime(2017, 5, 31).Date;
            Console.WriteLine(TymHracTable.Update(th1));
            foreach (Kontrakt k in TymHracTable.Seznam(""))
            {
                Console.WriteLine(k.id + " " + k.jmeno + " " + k.prijmeni + " " + k.cislo + " " + k.tym);
            }
            
            // TymTable
            Tym tm = new Tym();
            tm.kod = "CZ01020305";
            tm.nazev = "HC Mněsenechce";
            Console.WriteLine(TymTable.Vlozeni(tm));
            Tym tm1 = new Tym();
            tm1.kod = "CZ01020305";
            tm1.nazev = "HC Mně se nechce";
            Console.WriteLine(TymTable.Update(tm1));
            Console.WriteLine(TymTable.Delete("CZ01020301"));
           
            // UcastnikTable
            Ucastnik u = new Ucastnik();
            u.idTym = "CZ01020305";
            u.idRocnik = 1;
            Console.WriteLine(UcastnikTable.Insert(u));
            Ucastnik u1 = new Ucastnik();
            u1.idTym = "CZ01020305";
            u1.idRocnik = 1;
            u1.body = 3;
            Console.WriteLine(UcastnikTable.Update(u1));

            // ZapasTable
            foreach(Zapas z in ZapasTable.Seznam(new DateTime(2016, 9, 1).Date)){
                Console.WriteLine(z.domaci + " vs " + z.hoste + " " + z.skoreD + ":" + z.skoreH + " " + z.datum + " " + z.kolo);
            }
            Zapas z1 = new Zapas();
            z1.idZapas = 3;
            z1.domaci = "CZ01020303";
            z1.hoste = "CZ01020300";
            z1.datum = new DateTime(2016, 9, 8, 18, 20, 0);
            z1.kolo = 2;
            z1.skoreD = 3;
            z1.skoreH = 8;
            Console.WriteLine(ZapasTable.Insert(z1));
            Zapas z2 = new Zapas();
            z2.idZapas = 3;
            z2.domaci = "CZ01020303";
            z2.hoste = "CZ01020300";
            z2.datum = new DateTime(2016, 9, 8, 18, 20, 0);
            z2.kolo = 2;
            z2.skoreD = 3;
            z2.skoreH = 6;
            Console.WriteLine(ZapasTable.Update(z2));
            foreach(Hrac z3 in ZapasTable.Detail(1, "G"))
            {
                Console.WriteLine(z3.cislo + " " + z3.jmeno + " " + z3.prijmeni);
            }

            Console.ReadKey();
        }
    }
}
