﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HokejovaLigaORM.Databaze
{
    class Ucastnik
    {
        public string idTym { get; set; }
        public int idRocnik { get; set; }
        public int body { get; set; }
    }
}
