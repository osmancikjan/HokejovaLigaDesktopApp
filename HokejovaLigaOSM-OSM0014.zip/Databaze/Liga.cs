﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HokejovaLigaORM.Databaze
{
    public class Liga
    {
        public int idLiga { get; set; }
        public string nazev { get; set; }
    }
}
