﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HokejovaLigaORM.Databaze
{
    public class Bodovani
    {
        public int idZaznam { get; set; }
        public int idZapas { get; set; }
        public int idHrac { get; set; }
        public string typ { get; set; }
    }
}
