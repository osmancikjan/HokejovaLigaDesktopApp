﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HokejovaLigaORM.Databaze.ORM
{
    class TymTable
    {
        public static string SQL_UPDATE = "UPDATE Tym SET nazev = @nazev WHERE kod = @kod";
       
        public static int Vlozeni(Tym tym)
        {
            Database db;
            db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand("VlozeniTymu");
            command.CommandType = CommandType.StoredProcedure;
            PrepareCommand(command, tym);

            int ret = db.ExecuteNonQuery(command);

            db.Close();

            return ret;
        }
        
        public static int Update(Tym tym)
        {
            Database db;
            db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_UPDATE);
            PrepareCommand(command, tym);
            int ret = db.ExecuteNonQuery(command);

            db.Close();

            return ret;
        }

        public static int Delete(string kod)
        {
            Database db;
            db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand("VymazTym");
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@kod", kod);
            int ret = db.ExecuteNonQuery(command);

            db.Close();

            return ret;
        }
        private static void PrepareCommand(SqlCommand command, Tym tym)
        {
            command.Parameters.AddWithValue("@kod", tym.kod);
            command.Parameters.AddWithValue("@nazev", tym.nazev);
        }
    }
}
